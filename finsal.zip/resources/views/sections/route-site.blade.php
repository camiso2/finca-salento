<a href="https://maps.google.com/?q=4.62788,-75.59876&z=15" target="_blank">
    <img src="images/pv1.png" class="img-thumbnail img-responsive">
    <br><br>
    <button type="button" class="btn btn-primary  btn-block">
        <h3><i class="	fa fa-map-marker"></i>&nbsp;&nbsp;Como llegar ?</h3>
    </button>
</a>
