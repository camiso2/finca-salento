
<script type="text/javascript">

	function whatsapp_message(){
		var dir = "https://wa.me/57"+<?php echo e(env('PHONE')); ?>+"?text=Necesito%20Información%20del%20Hecohotel%20El%20Rosario%20";
		window.open(dir,'_blank');
	}
</script>
