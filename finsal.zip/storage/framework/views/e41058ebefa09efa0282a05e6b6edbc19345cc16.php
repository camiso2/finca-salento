<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>-->


    <meta name="keywords" content="natural, quindío, ecologica, Quindío"/>
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
            function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- //for-mobile-apps -->
    <link href="/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <link href="/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/animate.min.css" rel="stylesheet">
    <!-- js -->
    <script src="js/jquery-1.11.1.min.js"></script>
    <!-- //js -->
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Gabriela' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.css">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js"></script>

  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Styles
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">-->

    <?php echo htmlScriptTagJsApi(/* $formId - INVISIBLE version only */); ?>



</head>
<body>
<?php echo $__env->make('sections.floating-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('sections.whatsapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(session('alert_error')): ?>
<script>
    Swal.fire({
        title: 'UPPS',
        html: '<h1 style="color:#171717 !important; font-size:21px;overflow: hidden;"><?php echo e(session('alert_error')); ?></h1>',
        icon: 'error',
        confirmButtonColor: '#799F61',
        confirmButtonText: 'Seguir Navegando'
      })
</script>
<?php endif; ?>

<?php if(session('alert_success')): ?>
<script>
Swal.fire({
    title: 'Recibimos su Mensaje',
    html: '<h1 style="color:#171717 !important; font-size:21px;overflow: hidden;"><?php echo e(session('alert_success')); ?></h1>',
    icon: 'success',
    confirmButtonColor: '#799F61',
    confirmButtonText: 'Seguir Navegando'
  })

</script>
<?php endif; ?>

<?php if(session('alert_reserva')): ?>
<script>
Swal.fire({
    title: 'Información',
    html: '<h1 style="color:#171717 !important; font-size:21px;overflow: hidden;"><?php echo e(session('alert_reserva')); ?> Teléfono : <?php echo e(env('PHONE')); ?></h1>',
    icon: 'info',
    confirmButtonColor: '#799F61',
    confirmButtonText: 'Seguir Navegando'
  })

</script>
<?php endif; ?>

    

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
